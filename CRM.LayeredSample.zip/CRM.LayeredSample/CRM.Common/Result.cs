﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Common
{
    // 4. Customers.cs den geldim ...
    public class Result // bu classı -> Result datalarına geri döndürmede kullanacağım ...
    {
        // prop + tab + tab
        public bool IsSucceeded { get; set; }
        // ctor + tab + tab
        public Result()
        {
            IsSucceeded = false;
            // default'ta IsSucceeded işlemim defaultta kapalı olsun .. false (yani -> 0)
        }
    }

    public class Result<T> : Result
    {
        public T TransactionResult { get; set; }
    }

    // CRM.Dal adında Class Library açıp içinede - CustomerDal.cs adında bir class açıyorum oradayım
}
