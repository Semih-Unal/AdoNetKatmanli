﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Common
{
    // 7. SqlProvider.cs den geldim
    public class Tools
    {
        public static string ConnectionString
        {
            get {
                return "Server = .; Database = CrmDB; UID = sa; PWD=123"; // Integrated Security = true; veya yes
            }
        }

        // SqlProvider.cs ye geri dönüyorum
    }
}
