﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//---------------------------
using CRM.Entity;
using CRM.Common; // ekledik ...
using System.Data.SqlClient; // SqlDataReader için

namespace CRM.Dal
{
    // II.Yol olarak nameSpase içinde de usingle çekebiliyoruz...
    //using Entity;
    //using Common;

    // 5. Result.cs den geldim ... Referans'a -> Common ve Entity'yi ekleyip çekiyorum

   // CRM.Dal içine - SqlProvider.cs adında bir class açıp geliyorum ...
    public class CustomerDal
    {
        // 7. SqlProvider.cs'den geldim ... DML yapımızı burada tanımlayacağım ...

        public Result<Customers> ListOfCustomersbyID(int cusId)
        {
            Result<Customers> rlc = new Result<Customers>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Customers Where Id = @ID",false);
            sqlProvider.AddParameter("@ID", cusId);
            SqlDataReader reader = sqlProvider.ExecuteReader();

            rlc.IsSucceeded = rlc != null;

            Customers c = new Customers();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    //----------------------------
                    //I.yol 
                    c.Id = Convert.ToInt32(reader["Id"]);
                    //II.yol -> int olduğunda
                    //c.Id = Convert.ToInt32(reader.GetString(0));
                    // III.yol -> uniq olduğunda
                    //c.Id = reader.GetSqlGuid(0);

                    c.Name = reader["Name"].ToString();
                    c.SurName = reader["SurName"].ToString();
                    c.Phone = reader["Phone"].ToString();
                    c.Mail = reader["Mail"].ToString();
                    c.Address = reader["Address"].ToString();
                    c.City = reader["City"].ToString();
                    c.Country = reader["Country"].ToString();
                    //------------------------
                    c.Gender = Convert.ToBoolean(reader["Gender"]);
                    //------------------
                    c.PhotoPath = reader["PhotoPath"].ToString();
                    c.CreateDate = Convert.ToDateTime(reader["CreateDate"]);
                }
            }

            reader.Close();
            rlc.TransactionResult = c;

            return rlc;
        }

        // List metodum :

        public Result<List<Customers>> ListOfCustomers()
        {
            Result<List<Customers>> rlc = new Result<List<Customers>>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Customers",false);

            SqlDataReader reader = sqlProvider.ExecuteReader();


            rlc.IsSucceeded = rlc != null; // (rlc boş değilse success)

            List<Customers> allCustomer = new List<Customers>();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Customers c = new Customers();
                    //----------------------------
                    //I.yol 
                    c.Id = Convert.ToInt32(reader["Id"]);
                    //II.yol -> int olduğunda
                    //c.Id = Convert.ToInt32(reader.GetString(0));
                    // III.yol -> uniq olduğunda
                    //c.Id = reader.GetSqlGuid(0);

                    c.Name = reader["Name"].ToString();
                    c.SurName = reader["SurName"].ToString();
                    c.Phone = reader["Phone"].ToString();
                    c.Mail = reader["Mail"].ToString();
                    c.Address = reader["Address"].ToString();
                    c.City = reader["City"].ToString();
                    c.Country = reader["Country"].ToString();
                    //------------------------
                    c.Gender = Convert.ToBoolean(reader["Gender"]);
                    //------------------
                    c.PhotoPath = reader["PhotoPath"].ToString();
                    c.CreateDate = Convert.ToDateTime(reader["CreateDate"]);
                    //--------------------------

                    allCustomer.Add(c);

                }
            }
            reader.Close();
            rlc.TransactionResult = allCustomer;

            return rlc;
        }

        // Save Metodum :

        public Result Save(Customers instance)
        {
            Result result = new Result(); // IsSucceded = false;

            int returnValue = 0;

            SqlProvider sqlprovider = new SqlProvider("Insert Into Customers (Name,SurName,Address,Phone,Mail,City,Country,Gender,PhotoPath,CreateDate)Values(@Name,@SurName,@Address,@Phone,@Mail,@City,@Country,@Gender,@PhotoPath,@CreateDate)", false);
            
            sqlprovider.AddParameter("@Name", instance.Name);
            sqlprovider.AddParameter("@SurName", instance.SurName);
            sqlprovider.AddParameter("@Address", instance.Address);
            sqlprovider.AddParameter("@Phone", instance.Phone);
            sqlprovider.AddParameter("@Mail", instance.Mail);
            sqlprovider.AddParameter("@City", instance.City);
            sqlprovider.AddParameter("@Country", instance.Country);
            sqlprovider.AddParameter("@Gender", instance.Gender);
            sqlprovider.AddParameter("@PhotoPath", instance.PhotoPath);
            sqlprovider.AddParameter("@CreateDate", instance.CreateDate);

            returnValue = sqlprovider.ExecuteNonQuery();
            result.IsSucceeded = returnValue != -1;
            return result;
        }

        // Update Metodum :

        public Result Update(Customers newinstance)
        {
            Result result = new Result(); // IsSucceded = false;

            int returnValue = 0;

            SqlProvider sqlprovider = new SqlProvider("Update Customers Set Name=@Name, SurName=@SurName, Address=@Address, Phone=@Phone, Mail=@Mail, City=@City, Country=@Country, Gender=@Gender, PhotoPath=@PhotoPath, CreateDate=@CreateDate Where Id = @Id", false);

            sqlprovider.AddParameter("@Id", newinstance.Id);
            sqlprovider.AddParameter("@Name", newinstance.Name);
            sqlprovider.AddParameter("@SurName", newinstance.SurName);
            sqlprovider.AddParameter("@Address", newinstance.Address);
            sqlprovider.AddParameter("@Phone", newinstance.Phone);
            sqlprovider.AddParameter("@Mail", newinstance.Mail);
            sqlprovider.AddParameter("@City", newinstance.City);
            sqlprovider.AddParameter("@Country", newinstance.Country);
            sqlprovider.AddParameter("@Gender", newinstance.Gender);
            sqlprovider.AddParameter("@PhotoPath", newinstance.PhotoPath);
            sqlprovider.AddParameter("@CreateDate", newinstance.CreateDate);

            returnValue = sqlprovider.ExecuteNonQuery();
            result.IsSucceeded = returnValue != -1;
            return result;
        }

        //------------------------
        // Delete Metodum :

        public Result Delete(object instanceId)
        {
            Result result = new Result(); // IsSucceded = false;

            int returnValue = 0;

            SqlProvider sqlprovider = new SqlProvider("Delete From Customers Where Id = @Id", false);

            sqlprovider.AddParameter("@Id", instanceId);

            returnValue = sqlprovider.ExecuteNonQuery();

            result.IsSucceeded = returnValue != -1;
            return result;
        }
    }
}
