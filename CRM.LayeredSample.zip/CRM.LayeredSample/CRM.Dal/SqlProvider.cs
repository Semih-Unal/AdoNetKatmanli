﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//---------------------------
using CRM.Common;
using System.Data.SqlClient; // SqlConnection için ekledik
using System.Data; // ConnectionState için
namespace CRM.Dal
{
    // 6. CustomerDal.cs den geldim
    public class SqlProvider
    {
        // Ado.Net ile işlemlerimizi gerçekleştirelim ...

        #region fieldsAndConstructors
        // Fields alalım ...
        private SqlConnection cnn;
        private SqlCommand cmd;
        // Constructor alalım ..
        public SqlProvider(string commandText, bool isProcedure)
        {
            // cnn iletişim kısmını ayrı bir class üzeinden alalım ..
            // CRM.Common içine -- Tools.cs adında bir class açıyorum oradayım ...
            //----------------------------------------------------------------------------
            // 8. Tools.cs den geldim

            cnn = new SqlConnection(Tools.ConnectionString);

            cmd = new SqlCommand(commandText,cnn);

            cmd.CommandType = isProcedure ? System.Data.CommandType.StoredProcedure : System.Data.CommandType.Text; // Text -> sql sorgumuz ...


        }
        #endregion

        #region Parameters

        public void AddParameter (string parameterName, object value)
        {
            cmd.Parameters.AddWithValue(parameterName, value);
        }
        #endregion

        #region ConnectionMethods
        public void OpenConnection()
        {
            if (cnn.State == ConnectionState.Closed)
                cnn.Open();
        }
        public void CloseConnection()
        {
            if (cnn.State == ConnectionState.Open)
                cnn.Close();
        }
        #endregion

        #region ExecuteMethods
        // Select için :
        public SqlDataReader ExecuteReader()
        {
            OpenConnection();

            return cmd.ExecuteReader(CommandBehavior.CloseConnection); // veri çekme bittiğinde otamatikmen iletişimi kapat ...

            //CloseConnection();
        }
        //--------------------------------------
        // Insert/Update/Delete için :
        public int ExecuteNonQuery()
        {
            
            int result = -1;
            try
            {
                OpenConnection();
                result = cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                result = -1;
            }
            finally
            {
                CloseConnection();
            }
            return  result; 

            
        }
        //--------------------------------------
        // Scalar için :
        public object ExecuteScalar()
        {

            object result = null;
            try
            {
                OpenConnection();
                result = cmd.ExecuteScalar();
            }
            catch (Exception)
            {
                result = null;
            }
            finally
            {
                CloseConnection();
            }
            return result; 


        }
        #endregion

        // CustomerDal.cs deyim
    }
}
