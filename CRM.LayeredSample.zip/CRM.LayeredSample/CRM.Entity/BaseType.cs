﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Entity
{
    // 2. Formdan geldim ...
    public class BaseType // Entity classım gibi düşünün
    {
        // Base Classımız olacak ve burada tüm tablolardaki ortak alanları yani tüm sınıfların miras alacağı yer olarak alıyorum ...
        public int Id { get; set; }
        public DateTime? CreateDate { get; set; }
        // ? -> Nullable Type ile -> databaseden gelen verilerin boş olma durumunda (mesela tarih boş gelse, form patlayacak ...) bu struct yapının (DateTime) patlaması için istediğiniz tip yanına ? koyabilirsiniz ...

        // Id ve CreateDate tüm tablolarda ortak olduğu için Entity Base içinde tanımladıki diğer kolonları ise CRM.Entity - Customers.cs classı açıyorum ordayım
    }
}
