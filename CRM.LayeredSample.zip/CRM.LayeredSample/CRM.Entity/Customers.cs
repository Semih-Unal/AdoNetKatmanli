﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM.Entity
{
    // 3. BaseType.cs den geldim ...
    public class Customers : BaseType 
    {
        // ctor + tab + tab
        public Customers()
        {
            // Default olarak sql - getDate() yapısını burada da DateTime.Now ile almış olduk
            this.CreateDate = DateTime.Now;

            // Id için gerekirse guid ile manuel yapı oluşturabilirsiniz
            // sql -> Select NewId()
            // this.Id = Convert.ToInt32(Guid.NewGuid());
        }
        // prop + tab + tab
        public string Name { get; set; }
        public string SurName { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Mail { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public bool? Gender { get; set; } // Cinsiyet - bit olan kısım nullable type ile boş geçme olayını ortadan kaldırır
        public string PhotoPath { get; set; }

        // CRM.Common adında bir Class Library açıp içinede Result.cs classı açıyorum ordayım....
    }
}
