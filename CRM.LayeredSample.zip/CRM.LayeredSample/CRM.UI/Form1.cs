﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//----------------------
using CRM.Common;
using CRM.Entity;
using CRM.Dal;

namespace CRM.UI
{
    //----------------------
    //II.yol
    //using CRM.Common;
    //using CRM.Entity;
    //using CRM.Dal;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // CRM Project (Customer Relationship Management) - Müşteri İlişkileri Yönetim Sistemi ...
        // Normalde çok komplex bir yapıdır biz bunu katmanlı mimariye uyarlıyalım ...

        // sql'de -> "CrmDB" adında bir DB oluturup içinede "Customers" tablosu oluşturup geliyorum...

        // 1. Projeme - CRM.Entity adında bir class library açıp içinede BaseType.cs adında bir class açıyorum ordayım ...
        //-------------------------------------------------------------------------------------
        CustomerDal cusDal = new CustomerDal();

        int secilenID;
        private void Form1_Load(object sender, EventArgs e)
        {
            // 8. customerDal.cs den geldim
            // tüm referansları ekleyip, çekelim ...

            Listele();
        }

        private void Listele()
        {
            var result = cusDal.ListOfCustomers();

            if (result.IsSucceeded == true) // İşlem başarılı ise
            {
                dGwVeriler.DataSource = result.TransactionResult;
            }
        }

        private void ekleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEkle frmEk = new frmEkle();
            frmEk.Show();
            this.Hide();
        }

        private void güncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (secilenID == 0)
            {
                MessageBox.Show("Lütfen İşlem Yapmak İstediğiniz Veriyi Seçiniz !!!");
                return;
            }
            var result = cusDal.ListOfCustomersbyID(secilenID);
            frmGuncelle frmGuncel = new frmGuncelle((Customers)result.TransactionResult);
            this.Hide();
            frmGuncel.Show();
        }

        private void dGwVeriler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            secilenID = (int)dGwVeriler.CurrentRow.Cells[9].Value;
        }

        private void silToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (secilenID == 0)
            {
                MessageBox.Show("Lütfen İşlem Yapmak İstediğiniz Veriyi Seçiniz !!!");
                return;
            }
            var result = cusDal.Delete(secilenID);

            MessageBox.Show(result.IsSucceeded == true ? "İşleminiz başarılı ile gerçekleştirildi..." : "Hatayla karşılaşıldı, tekrar deneyiniz!!");
            Listele();
        }

        // Ekleme / Güncelleme ve Silme kısmını ister DataGridView üzerinden, ister yavru formlarla istediğiniz şekilde tasarlayınız

        //bitti..
    }
}
