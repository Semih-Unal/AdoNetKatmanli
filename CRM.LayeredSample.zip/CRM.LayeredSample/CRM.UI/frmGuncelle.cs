﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//---------------------
using CRM.Common;
using CRM.Entity;
using CRM.Dal;
using System.IO;

namespace CRM.UI
{
    public partial class frmGuncelle : Form
    {
        CustomerDal cusDal = new CustomerDal();
        int secilenID;
        public frmGuncelle(Customers c)
        {
            InitializeComponent();
            secilenID = c.Id;
            txtName.Text = c.Name;
            txtSurName.Text = c.SurName;
            if (c.Gender == false)
                rbMan.Checked = true;
            else
                rbWoman.Checked = true;

            mtxtPhone.Text = c.Phone;
            txtMail.Text = c.Mail;
            txtCountry.Text = c.Country;
            txtCity.Text = c.City;
            txtAddress.Text = c.Address;
            txtResim.Text = c.PhotoPath;
            if (c.PhotoPath != "")
                pbResim.Image = Image.FromFile(c.PhotoPath);

        }
        string path;
        private void btnResimSec_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                path = ofd.FileName;
                pbResim.Image = Image.FromFile(path);
                txtResim.Text = path;
            }
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            int gender = rbMan.Checked == true ? 0 : 1;
            string Resim = "";

            if (path != "" && path !=null)
            {
                 Resim = @"..\..\Images\ " + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(path);

                Image img = Image.FromFile(path);

                img.Save(Resim); // resmi kaydettik
            }
            else
            {
                Resim = txtResim.Text;
            }

            Customers cus = new Customers()
            {
                Id = secilenID,
                Name = txtName.Text,
                SurName = txtSurName.Text,
                Address = txtAddress.Text,
                City = txtCity.Text,
                Country = txtCountry.Text,
                Mail = txtMail.Text,
                Phone = mtxtPhone.Text,
                Gender = Convert.ToBoolean(gender),
                PhotoPath = Resim
            };

            var result = cusDal.Update(cus);
            if (result.IsSucceeded == true)
            {
                MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
                Form1 frmAna = new Form1();
                this.Hide();
                frmAna.Show();
            }
            else
            {
                MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");
            }
        }

        private void btnCik_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Close();
        }
    }
}
